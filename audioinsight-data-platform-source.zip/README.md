# AudioInsight Data Platform

An end-to-end, portfolio-ready data engineering project for an audio-content product. It ingests listener events, applies data-quality rules, quarantines bad records, and loads an analytics-ready star schema.

It is deliberately framed around a Kuku FM-style product while demonstrating the data-engineering capabilities sought by internship roles: SQL, ETL, data quality, dimensional modelling, PostgreSQL-ready DDL, and reproducible analytics.

## What it does

```text
CSV event data -> validation and quarantine -> transform -> star-schema warehouse -> SQL insights
```

- Validates required fields, event timestamps, completion rates, listening duration, and foreign keys.
- Sends invalid records to `data/quarantine/rejected_events.csv` with a rejection reason.
- Builds `dim_listener`, `dim_content`, `dim_date`, and `fact_listening_event` tables.
- Keeps an `etl_run_audit` log with accepted and rejected row counts.
- Is idempotent: re-running it updates existing warehouse records rather than duplicating them.
- Uses Python's standard library and SQLite for a zero-dependency demo. A PostgreSQL-compatible schema is included in `sql/postgres_schema.sql`.

## Project structure

```text
audioinsight-data-platform/
├── data/raw/                 # Source listener, content, and user data
├── data/quarantine/          # Invalid event records written by the pipeline
├── data/warehouse/           # Generated SQLite warehouse (ignored by Git)
├── sql/                      # PostgreSQL DDL and business analysis queries
├── src/audio_warehouse/      # ETL pipeline code
├── tests/                    # Automated data-quality and idempotency tests
└── run_pipeline.py           # Pipeline entry point
```

## Run it

Requires Python 3.10+ and no external packages.

```bash
python run_pipeline.py
python -m unittest discover -s tests -v
```

The pipeline creates `data/warehouse/audio_analytics.db`. Open it in DB Browser for SQLite or run the queries in `sql/analytics_queries.sql` from any SQLite client.

## Warehouse model

| Table | Purpose |
| --- | --- |
| `dim_listener` | Listener profile and acquisition channel |
| `dim_content` | Story metadata, genre, creator, and duration |
| `dim_date` | Calendar attributes for reporting |
| `fact_listening_event` | Granular listening events and engagement metrics |
| `etl_run_audit` | Pipeline observability and load statistics |

## Resume-ready project entry

**AudioInsight Data Platform | Python, SQL, SQLite/PostgreSQL, Data Quality**

- Built an idempotent ETL pipeline to ingest and transform listener-event data into a star-schema warehouse with listener, content, and date dimensions.
- Implemented schema, referential-integrity, timestamp, and metric validations; quarantined invalid events and recorded load-level audit metrics for traceability.
- Wrote SQL analyses for daily engagement, completion rate, and top-performing audio content to support product and content decisions.

Only use this entry after you can run the project, explain the schema, and describe each validation rule in your own words.

## Suggested extensions

1. Replace the CSV source with a PostgreSQL or API ingestion job.
2. Schedule the pipeline with Airflow or Prefect.
3. Add dbt tests and documentation for warehouse transformations.
4. Publish the warehouse tables to BigQuery or Snowflake.
5. Build a Power BI dashboard using the three included analytics queries.
