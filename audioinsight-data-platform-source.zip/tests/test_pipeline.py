import csv
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from src.audio_warehouse.pipeline import run_pipeline  # noqa: E402


class PipelineTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary_directory = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary_directory.name)
        raw = self.root / "data" / "raw"
        raw.mkdir(parents=True)
        self._write(raw / "users.csv", ["user_id", "city", "acquisition_channel", "signup_date"], [
            {"user_id": "u1", "city": "Mumbai", "acquisition_channel": "organic", "signup_date": "2026-01-01"}
        ])
        self._write(raw / "content_catalog.csv", ["content_id", "title", "genre", "creator", "duration_seconds"], [
            {"content_id": "c1", "title": "Sample", "genre": "History", "creator": "Author", "duration_seconds": "600"}
        ])
        self._write(raw / "listener_events.csv", [
            "event_id", "user_id", "content_id", "event_timestamp", "event_type", "listen_seconds", "completion_rate", "device"
        ], [
            {"event_id": "e1", "user_id": "u1", "content_id": "c1", "event_timestamp": "2026-01-02T10:00:00+05:30", "event_type": "play", "listen_seconds": "120", "completion_rate": "0.2", "device": "android"},
            {"event_id": "e2", "user_id": "u1", "content_id": "c1", "event_timestamp": "not-a-date", "event_type": "play", "listen_seconds": "120", "completion_rate": "0.2", "device": "android"},
        ])

    def tearDown(self) -> None:
        self.temporary_directory.cleanup()

    @staticmethod
    def _write(path: Path, fields: list[str], rows: list[dict[str, str]]) -> None:
        with path.open("w", newline="", encoding="utf-8") as file:
            writer = csv.DictWriter(file, fieldnames=fields)
            writer.writeheader()
            writer.writerows(rows)

    def test_pipeline_quarantines_invalid_rows_and_is_idempotent(self) -> None:
        first_run = run_pipeline(self.root)
        second_run = run_pipeline(self.root)

        self.assertEqual(first_run.accepted_events, 1)
        self.assertEqual(first_run.rejected_events, 1)
        self.assertEqual(second_run.accepted_events, 1)

        connection = sqlite3.connect(first_run.warehouse_path)
        try:
            fact_count = connection.execute("SELECT COUNT(*) FROM fact_listening_event").fetchone()[0]
            audit_count = connection.execute("SELECT COUNT(*) FROM etl_run_audit").fetchone()[0]
        finally:
            connection.close()
        self.assertEqual(fact_count, 1)
        self.assertEqual(audit_count, 2)


if __name__ == "__main__":
    unittest.main()
