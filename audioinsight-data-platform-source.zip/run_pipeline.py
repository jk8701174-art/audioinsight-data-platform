from pathlib import Path

from src.audio_warehouse.pipeline import run_pipeline


if __name__ == "__main__":
    project_root = Path(__file__).resolve().parent
    result = run_pipeline(project_root)
    print(
        f"Pipeline run {result.run_id} completed: "
        f"{result.accepted_events} accepted, {result.rejected_events} quarantined."
    )
