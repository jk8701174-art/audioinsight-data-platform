"""Extract, validate, transform, and load AudioInsight source data."""

from __future__ import annotations

import csv
import sqlite3
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable


EVENT_COLUMNS = {
    "event_id",
    "user_id",
    "content_id",
    "event_timestamp",
    "event_type",
    "listen_seconds",
    "completion_rate",
    "device",
}
VALID_EVENT_TYPES = {"play", "pause", "complete", "skip"}


@dataclass(frozen=True)
class PipelineResult:
    run_id: str
    accepted_events: int
    rejected_events: int
    warehouse_path: Path


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as source:
        return list(csv.DictReader(source))


def write_csv(path: Path, rows: Iterable[dict[str, str]], fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as target:
        writer = csv.DictWriter(target, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def parse_timestamp(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def validate_event(
    event: dict[str, str], user_ids: set[str], content_ids: set[str]
) -> str | None:
    missing = [column for column in EVENT_COLUMNS if not event.get(column, "").strip()]
    if missing:
        return f"Missing required field(s): {', '.join(sorted(missing))}"
    if event["event_type"] not in VALID_EVENT_TYPES:
        return f"Unsupported event type: {event['event_type']}"
    if event["user_id"] not in user_ids:
        return f"Unknown user_id: {event['user_id']}"
    if event["content_id"] not in content_ids:
        return f"Unknown content_id: {event['content_id']}"
    try:
        parse_timestamp(event["event_timestamp"])
    except ValueError:
        return "Invalid event_timestamp; expected ISO-8601 format"
    try:
        listen_seconds = int(event["listen_seconds"])
        completion_rate = float(event["completion_rate"])
    except ValueError:
        return "listen_seconds must be an integer and completion_rate must be numeric"
    if listen_seconds < 0:
        return "listen_seconds cannot be negative"
    if not 0 <= completion_rate <= 1:
        return "completion_rate must be between 0 and 1"
    return None


def initialise_schema(connection: sqlite3.Connection) -> None:
    connection.executescript(
        """
        PRAGMA foreign_keys = ON;

        CREATE TABLE IF NOT EXISTS dim_listener (
            listener_key INTEGER PRIMARY KEY,
            user_id TEXT NOT NULL UNIQUE,
            city TEXT NOT NULL,
            acquisition_channel TEXT NOT NULL,
            signup_date TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS dim_content (
            content_key INTEGER PRIMARY KEY,
            content_id TEXT NOT NULL UNIQUE,
            title TEXT NOT NULL,
            genre TEXT NOT NULL,
            creator TEXT NOT NULL,
            duration_seconds INTEGER NOT NULL CHECK (duration_seconds > 0)
        );

        CREATE TABLE IF NOT EXISTS dim_date (
            date_key INTEGER PRIMARY KEY,
            full_date TEXT NOT NULL UNIQUE,
            year INTEGER NOT NULL,
            month INTEGER NOT NULL,
            day INTEGER NOT NULL,
            weekday TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS fact_listening_event (
            event_id TEXT PRIMARY KEY,
            listener_key INTEGER NOT NULL,
            content_key INTEGER NOT NULL,
            date_key INTEGER NOT NULL,
            event_timestamp TEXT NOT NULL,
            event_type TEXT NOT NULL,
            listen_seconds INTEGER NOT NULL CHECK (listen_seconds >= 0),
            completion_rate REAL NOT NULL CHECK (completion_rate BETWEEN 0 AND 1),
            device TEXT NOT NULL,
            FOREIGN KEY (listener_key) REFERENCES dim_listener(listener_key),
            FOREIGN KEY (content_key) REFERENCES dim_content(content_key),
            FOREIGN KEY (date_key) REFERENCES dim_date(date_key)
        );

        CREATE TABLE IF NOT EXISTS etl_run_audit (
            run_id TEXT PRIMARY KEY,
            started_at TEXT NOT NULL,
            completed_at TEXT NOT NULL,
            accepted_events INTEGER NOT NULL,
            rejected_events INTEGER NOT NULL,
            status TEXT NOT NULL
        );
        """
    )


def upsert_dimensions(
    connection: sqlite3.Connection,
    users: list[dict[str, str]],
    content: list[dict[str, str]],
) -> None:
    connection.executemany(
        """
        INSERT INTO dim_listener (user_id, city, acquisition_channel, signup_date)
        VALUES (:user_id, :city, :acquisition_channel, :signup_date)
        ON CONFLICT(user_id) DO UPDATE SET
            city = excluded.city,
            acquisition_channel = excluded.acquisition_channel,
            signup_date = excluded.signup_date
        """,
        users,
    )
    connection.executemany(
        """
        INSERT INTO dim_content (content_id, title, genre, creator, duration_seconds)
        VALUES (:content_id, :title, :genre, :creator, :duration_seconds)
        ON CONFLICT(content_id) DO UPDATE SET
            title = excluded.title,
            genre = excluded.genre,
            creator = excluded.creator,
            duration_seconds = excluded.duration_seconds
        """,
        content,
    )


def ensure_date(connection: sqlite3.Connection, event_time: datetime) -> int:
    event_date = event_time.date()
    date_key = int(event_date.strftime("%Y%m%d"))
    connection.execute(
        """
        INSERT INTO dim_date (date_key, full_date, year, month, day, weekday)
        VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT(date_key) DO NOTHING
        """,
        (
            date_key,
            event_date.isoformat(),
            event_date.year,
            event_date.month,
            event_date.day,
            event_date.strftime("%A"),
        ),
    )
    return date_key


def load_events(connection: sqlite3.Connection, events: list[dict[str, str]]) -> None:
    for event in events:
        event_time = parse_timestamp(event["event_timestamp"])
        date_key = ensure_date(connection, event_time)
        listener_key = connection.execute(
            "SELECT listener_key FROM dim_listener WHERE user_id = ?", (event["user_id"],)
        ).fetchone()[0]
        content_key = connection.execute(
            "SELECT content_key FROM dim_content WHERE content_id = ?", (event["content_id"],)
        ).fetchone()[0]
        connection.execute(
            """
            INSERT INTO fact_listening_event (
                event_id, listener_key, content_key, date_key, event_timestamp,
                event_type, listen_seconds, completion_rate, device
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(event_id) DO UPDATE SET
                listener_key = excluded.listener_key,
                content_key = excluded.content_key,
                date_key = excluded.date_key,
                event_timestamp = excluded.event_timestamp,
                event_type = excluded.event_type,
                listen_seconds = excluded.listen_seconds,
                completion_rate = excluded.completion_rate,
                device = excluded.device
            """,
            (
                event["event_id"],
                listener_key,
                content_key,
                date_key,
                event["event_timestamp"],
                event["event_type"],
                int(event["listen_seconds"]),
                float(event["completion_rate"]),
                event["device"],
            ),
        )


def run_pipeline(project_root: Path, warehouse_path: Path | None = None) -> PipelineResult:
    """Run a complete, idempotent ETL load from the project data directory."""
    raw_directory = project_root / "data" / "raw"
    users = read_csv(raw_directory / "users.csv")
    content = read_csv(raw_directory / "content_catalog.csv")
    source_events = read_csv(raw_directory / "listener_events.csv")

    user_ids = {row["user_id"] for row in users}
    content_ids = {row["content_id"] for row in content}
    accepted: list[dict[str, str]] = []
    rejected: list[dict[str, str]] = []
    seen_event_ids: set[str] = set()

    for event in source_events:
        reason = validate_event(event, user_ids, content_ids)
        if not reason and event["event_id"] in seen_event_ids:
            reason = f"Duplicate event_id in source file: {event['event_id']}"
        if reason:
            rejected.append({**event, "rejection_reason": reason})
        else:
            seen_event_ids.add(event["event_id"])
            accepted.append(event)

    quarantine_path = project_root / "data" / "quarantine" / "rejected_events.csv"
    quarantine_fields = list(source_events[0].keys()) + ["rejection_reason"]
    write_csv(quarantine_path, rejected, quarantine_fields)

    warehouse_path = warehouse_path or project_root / "data" / "warehouse" / "audio_analytics.db"
    warehouse_path.parent.mkdir(parents=True, exist_ok=True)
    run_id = str(uuid.uuid4())
    started_at = datetime.now(timezone.utc).isoformat()

    connection = sqlite3.connect(warehouse_path)
    try:
        initialise_schema(connection)
        upsert_dimensions(connection, users, content)
        load_events(connection, accepted)
        connection.execute(
            """
            INSERT INTO etl_run_audit (
                run_id, started_at, completed_at, accepted_events, rejected_events, status
            ) VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                run_id,
                started_at,
                datetime.now(timezone.utc).isoformat(),
                len(accepted),
                len(rejected),
                "completed",
            ),
        )
        connection.commit()
    finally:
        connection.close()

    return PipelineResult(run_id, len(accepted), len(rejected), warehouse_path)
