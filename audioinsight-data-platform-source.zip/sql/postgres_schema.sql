-- PostgreSQL version of the warehouse schema. The demo pipeline uses SQLite
-- so it can run with no dependencies; use this DDL when deploying to Postgres.

CREATE TABLE IF NOT EXISTS dim_listener (
    listener_key BIGSERIAL PRIMARY KEY,
    user_id TEXT NOT NULL UNIQUE,
    city TEXT NOT NULL,
    acquisition_channel TEXT NOT NULL,
    signup_date DATE NOT NULL
);

CREATE TABLE IF NOT EXISTS dim_content (
    content_key BIGSERIAL PRIMARY KEY,
    content_id TEXT NOT NULL UNIQUE,
    title TEXT NOT NULL,
    genre TEXT NOT NULL,
    creator TEXT NOT NULL,
    duration_seconds INTEGER NOT NULL CHECK (duration_seconds > 0)
);

CREATE TABLE IF NOT EXISTS dim_date (
    date_key INTEGER PRIMARY KEY,
    full_date DATE NOT NULL UNIQUE,
    year INTEGER NOT NULL,
    month INTEGER NOT NULL,
    day INTEGER NOT NULL,
    weekday TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS fact_listening_event (
    event_id TEXT PRIMARY KEY,
    listener_key BIGINT NOT NULL REFERENCES dim_listener(listener_key),
    content_key BIGINT NOT NULL REFERENCES dim_content(content_key),
    date_key INTEGER NOT NULL REFERENCES dim_date(date_key),
    event_timestamp TIMESTAMPTZ NOT NULL,
    event_type TEXT NOT NULL,
    listen_seconds INTEGER NOT NULL CHECK (listen_seconds >= 0),
    completion_rate NUMERIC(5,4) NOT NULL CHECK (completion_rate BETWEEN 0 AND 1),
    device TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS etl_run_audit (
    run_id UUID PRIMARY KEY,
    started_at TIMESTAMPTZ NOT NULL,
    completed_at TIMESTAMPTZ NOT NULL,
    accepted_events INTEGER NOT NULL,
    rejected_events INTEGER NOT NULL,
    status TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_fact_listening_event_date_key
    ON fact_listening_event (date_key);
CREATE INDEX IF NOT EXISTS idx_fact_listening_event_content_key
    ON fact_listening_event (content_key);
