-- 1. Daily active listeners, listening time, and average completion.
SELECT
    d.full_date,
    COUNT(DISTINCT f.listener_key) AS daily_active_listeners,
    SUM(f.listen_seconds) / 60.0 AS listening_minutes,
    ROUND(AVG(f.completion_rate) * 100, 1) AS avg_completion_pct
FROM fact_listening_event AS f
JOIN dim_date AS d ON f.date_key = d.date_key
GROUP BY d.full_date
ORDER BY d.full_date;

-- 2. Content performance for editorial and recommendation decisions.
SELECT
    c.title,
    c.genre,
    COUNT(*) AS events,
    COUNT(DISTINCT f.listener_key) AS unique_listeners,
    ROUND(SUM(f.listen_seconds) / 60.0, 1) AS listening_minutes,
    ROUND(AVG(f.completion_rate) * 100, 1) AS avg_completion_pct
FROM fact_listening_event AS f
JOIN dim_content AS c ON f.content_key = c.content_key
GROUP BY c.title, c.genre
ORDER BY listening_minutes DESC, avg_completion_pct DESC;

-- 3. Engagement by acquisition channel to assess listener quality.
SELECT
    l.acquisition_channel,
    COUNT(DISTINCT f.listener_key) AS listeners,
    ROUND(AVG(f.completion_rate) * 100, 1) AS avg_completion_pct,
    ROUND(SUM(f.listen_seconds) / 60.0, 1) AS listening_minutes
FROM fact_listening_event AS f
JOIN dim_listener AS l ON f.listener_key = l.listener_key
GROUP BY l.acquisition_channel
ORDER BY avg_completion_pct DESC;
